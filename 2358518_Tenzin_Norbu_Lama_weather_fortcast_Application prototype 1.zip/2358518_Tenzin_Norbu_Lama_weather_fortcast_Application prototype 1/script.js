const apiKey = "98cbffea2ef6d6011f599f33ae87edde";

function fetchWeather(city) {
    const url = `https://api.openweathermap.org/data/2.5/weather?units=metric&q=${city}&appid=${apiKey}`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            const cityElement = document.getElementById("city");
            const temperatureElement = document.getElementById("temperature");
            const descriptionElement = document.getElementById("description");
            const pressureElement = document.getElementById("pressure");
            const humidityElement = document.getElementById("humidity");
            const windElement = document.getElementById("wind");
            const weatherIconElement = document.getElementById("weather-icon");

            cityElement.innerHTML = `Weather in ${data.name}`;
            temperatureElement.innerHTML = `${data.main.temp}°C`;
            descriptionElement.innerHTML = data.weather[0].description;
            pressureElement.innerHTML = `Pressure: ${data.main.pressure} hPa`;
            humidityElement.innerHTML = `Humidity: ${data.main.humidity}%`;
            windElement.innerHTML = `Wind: ${data.wind.speed} km/h`;

            const weatherDescription = data.weather[0].description;
            weatherIconElement.className = "icon";
            weatherIconElement.classList.add(getWeatherIconClass(weatherDescription));
        })
        .catch(error => {
            console.log(error);
            alert("Error fetching weather data. Please try again later.");
        });
}

function getWeatherIconClass(weatherDescription) {
    const descriptionLowerCase = weatherDescription.toLowerCase();
    if (descriptionLowerCase.includes("clear")) {
        return "wi wi-day-sunny";
    } else if (descriptionLowerCase.includes("cloud")) {
        return "wi wi-cloud";
    } else if (descriptionLowerCase.includes("rain")) {
        return "wi wi-rain";
    } else if (descriptionLowerCase.includes("snow")) {
        return "wi wi-snow";
    } else if (descriptionLowerCase.includes("thunderstorm")) {
        return "wi wi-thunderstorm";
    } else if (descriptionLowerCase.includes("mist")) {
        return "wi wi-fog";
    }
    return "wi wi-day-cloudy";
}

function searchWeather() {
    const cityInput = document.getElementById("search-bar");
    const city = cityInput.value;

    if (city.trim() === "") {
        alert("Please enter a city name.");
        return;
    }

    fetchWeather(city);
    cityInput.value = "";
}
window.addEventListener("load", function() {
    fetchWeather("Cambridgeshire");
});
